const { User } = require('../DB_connection');

const postUser = async (req, res) => {
  try {
    const { email, password } = req.body; // Extrae el email y password del cuerpo de la solicitud

    if (!email || !password) {
      // Si falta alguno de los datos
      return res.status(400).json({ message: 'Faltan datos' });
    }

    // Guardar el nuevo usuario utilizando el método findOrCreate
    const [user, created] = await User.findOrCreate({
      where: { email }, // Busca por el email
      defaults: { password }, // Si no existe, crea un nuevo registro con el email y password
    });

    if (created) {
      return res.status(201).json(user); // Usuario creado exitosamente
    } else {
      return res.status(409).json({ message: 'El usuario ya existe' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al crear el usuario' });
  }
};

module.exports = postUser; // Exporta la función postUser para usarla en otros archivos
